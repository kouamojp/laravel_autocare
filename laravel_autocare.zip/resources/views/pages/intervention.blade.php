<?php
use App\Models\Offre;
use App\Models\Vehicule;
?>

@extends(backpack_view('blank'))

@php
$defaultBreadcrumbs = [
trans('backpack::crud.admin') => url(config('backpack.base.route_prefix'), 'dashboard'),
$crud->entity_name_plural => url($crud->route),
trans('backpack::crud.add') => false,
];

// if breadcrumbs aren't defined in the CrudController, use the default breadcrumbs
$breadcrumbs = $breadcrumbs ?? $defaultBreadcrumbs;
@endphp

@section('header')
<section class="container-fluid">
	<h2>
		<span class="text-capitalize">{!! $crud->getHeading() ?? $crud->entity_name_plural !!}</span>
		<small>{!! $crud->getSubheading() ?? trans('backpack::crud.add').' '.$crud->entity_name !!}.</small>

		@if ($crud->hasAccess('list'))
		<small><a href="{{ url($crud->route) }}" class="d-print-none font-sm"><i class="la la-angle-double-{{ config('backpack.base.html_direction') == 'rtl' ? 'right' : 'left' }}"></i> {{ trans('backpack::crud.back_to_all') }} <span>{{ $crud->entity_name_plural }}</span></a></small>
		@endif
	</h2>
</section>
@endsection

@section('content')

<div class="row">
	<div class="{{ $crud->getCreateContentClass() }}">
		<!-- Default box -->

		@include('crud::inc.grouped_errors')

		<form method="post"
		action="{{ url($crud->route) }}"
		@if ($crud->hasUploadFields('create'))
		enctype="multipart/form-data"
		@endif
		>
		{!! csrf_field() !!}
		

		<div class="form-row">
			<div class="form-group col-md-6">
				<label for="date">Date</label>
				<input type="date" class="form-control" id="date_intrv" name="date_intrv" placeholder="Date de l'intervention">
			</div>
			<div class="form-group col-md-6">
				<label for="type">Type</label>
				
				<select id="type" class="form-control" name="type">
					<option selected>Selectionnez...</option>
					<option value="preventive">Préventive</option>
					<option value="corrective">Corrective</option>
				</select>
			</div>
		</div>
		<div class="form-row">
			<div class="form-group col-md-6">
				<label for="matricule">Matricule</label>
				<input type="text" class="form-control" id="matricule" name="matricule">
			</div>
			<div class="form-group col-md-6">
				<label for="km">Kilométrage</label>
				<input type="text" class="form-control" id="km" placeholder="km" name="kilometrage">
			</div>
			
		</div>

		<div class="form-row">
			<div class="form-group col-md-4">
				<label for="type">Offre</label>
				<select id="offre" class="form-control" name="offre_id">
					<option selected>Selectionnez l'offre...</option>
					@foreach (Offre::All() as $item)
					<option value="<?=$item->id?>"> <?=$item->intitule_type?></option>
					@endforeach
				</select>
			</div>

			<div class="form-group col-md-8">
				<label for="type">Intervention</label>
				<select id="offre" class="form-control" name="elements">
					<option selected>Selectionnez l'offre...</option>
					@foreach (Offre::All() as $item)
					<option value="<?=$item->id?>"> <?=$item->intitule_type?></option>
					@endforeach
				</select>		
			</div>
		</div>


	</div>
</div>


<div class="form-row">
	<div class="form-group">
		<label for="prochaine_interv">Date prochaine intervention</label>
		<input type="date" class="form-control" id="prochaine_interv" name="prochaine_interv" placeholder="Date prochaine intervention">
	</div>
</div>

@include('crud::inc.form_save_buttons')
</form>

<script
src=//code.jquery.com/jquery-3.5.1.min.js
integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
crossorigin=anonymous></script>
<script type=text/javascript>
	$(document).ready(function() {
		$("[name='offre_id']").click(function() { 
        /* $.ajax({  //create an ajax request to display.php
         	type: "GET",
         	url: "get-blog-list/",       
         	success: function (data) {
         		/*$("#title").html(data.title);
         		$("#description").html(data.description);
         		$('#prochaine_interv').html('OK');
         	}
         	
         });*/
         $('#prochaine_interv').html('OK');
     });
	});

</script>

</div>
</div>

@endsection

