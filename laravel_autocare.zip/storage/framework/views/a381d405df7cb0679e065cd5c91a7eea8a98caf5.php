<?php if($crud->hasAccess('create')): ?>
<a href="<?php echo e(url($crud->route.'/create')); ?>" class="btn btn-primary" data-style="zoom-in"><span class="ladda-label"><i class="la la-plus"></i>  Ajouter <?php echo e($crud->entity_name); ?></span></a>
<?php endif; ?><?php /**PATH C:\wamp64\www\autocare_app\laravel_autocare\resources\views/vendor/backpack/crud/buttons/create.blade.php ENDPATH**/ ?>