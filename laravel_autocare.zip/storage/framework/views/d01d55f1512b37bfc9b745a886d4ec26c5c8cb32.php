<!-- This file is used to store sidebar items, starting with Backpack\Base 0.9.0 -->
<li class="nav-item"><a class="nav-link" href="<?php echo e(backpack_url('dashboard')); ?>"><i class="la la-home nav-icon"></i> Tableau de Bord</a></li>
<li class='nav-item'><a class='nav-link' href='<?php echo e(backpack_url('client')); ?>'><i class='nav-icon la la-question'></i> Clients</a></li>

<li class='nav-item'><a class='nav-link' href='<?php echo e(backpack_url('technicien')); ?>'><i class='nav-icon la la-question'></i> Techniciens</a></li>
<li class='nav-item'><a class='nav-link' href='<?php echo e(backpack_url('vehicule')); ?>'><i class='nav-icon la la-question'></i> Vehicules</a></li>
<li class='nav-item'><a class='nav-link' href='<?php echo e(backpack_url('offre')); ?>'><i class='nav-icon la la-question'></i> Offres</a></li>
<li class='nav-item'><a class='nav-link' href='<?php echo e(backpack_url('intervention')); ?>'><i class='nav-icon la la-question'></i> Interventions</a></li>
<li class='nav-item'><a class='nav-link' href='<?php echo e(backpack_url('action_intervention')); ?>'><i class='nav-icon la la-question'></i> Liste des actions</a></li>
<li class='nav-item'><a class='nav-link' href='<?php echo e(backpack_url('devis')); ?>'><i class='nav-icon la la-question'></i> Devis</a></li>
<li class='nav-item'><a class='nav-link' href='<?php echo e(backpack_url('facture')); ?>'><i class='nav-icon la la-question'></i> Factures</a></li>

<!-- Users, Roles, Permissions -->
<li class="nav-item nav-dropdown">
	<a class="nav-link nav-dropdown-toggle" href="#"><i class="nav-icon la la-users"></i> Authentification</a>
	<ul class="nav-dropdown-items">
		<li class="nav-item"><a class="nav-link" href="<?php echo e(backpack_url('user')); ?>"><i class="nav-icon la la-user"></i> <span>Utilisateurs</span></a></li>
		<li class="nav-item"><a class="nav-link" href="<?php echo e(backpack_url('role')); ?>"><i class="nav-icon la la-id-badge"></i> <span>Roles</span></a></li>
		<li class="nav-item"><a class="nav-link" href="<?php echo e(backpack_url('permission')); ?>"><i class="nav-icon la la-key"></i> <span>Permissions</span></a></li>
	</ul>
</li>
<?php /**PATH C:\wamp64\www\autocare_app\laravel_autocare\resources\views/vendor/backpack/base/inc/sidebar_content.blade.php ENDPATH**/ ?>