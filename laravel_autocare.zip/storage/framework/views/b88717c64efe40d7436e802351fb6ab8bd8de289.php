<!-- This file is used to store topbar (right) items -->



<?php /**PATH C:\wamp64\www\autocare_app\laravel_autocare\resources\views/vendor/backpack/base/inc/topbar_right_content.blade.php ENDPATH**/ ?>