<?php
$widgets['before_content'][] = [
'type'        => 'jumbotron',
'heading'     => trans('Tableau de bord'),
//'content'     => trans('backpack::base.use_sidebar'),
//'button_link' => backpack_url('logout'),
//'button_text' => trans('backpack::base.logout'),
];

$nbre_vehicule = App\Models\Vehicule::count();
$nbre_client = App\Models\Client::count();
$nbre_interv = App\Models\Intervention::count();

$vehicules= App\Models\Vehicule::all();




$widgets['after_content'][] = [
'type'    => 'div',
'class'   => 'row',

'content' => [

[ 'type' => 'card', 
'content'    => [
'header' => 'Nombre de véhicules :'.$nbre_client,  
'body'   => ''
]],



[ 'type' => 'card', 
'content'    => [
'header' => 'Nombre de clients :'.$nbre_client,  
'body'   => ''
]],

[ 'type' => 'card', 
'content'    => [
'header' => 'Nombre d\'intervention :'.$nbre_interv,  
'body'   => ''
]],

]
]



?>

<?php $__env->startSection('content'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make(backpack_view('blank'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\autocare_app\laravel_autocare\resources\views/vendor/backpack/base/dashboard.blade.php ENDPATH**/ ?>